from hl7apy import core
from hl7apy.core import Message
import json
from pprint import pprint
import boto3, random


with open('data.json') as data_file:
	data = json.load(data_file)

pprint(data)

print data["maps"][0]["id"]
data["masks"]["id"]    
data["om_points"]


#m = Message("ADT_A01")
#m2 = Message()

#pid = Segment("PID")
#patient_group = Group("OML_O33_PATIENT")

# add a Segment instance
#m.add(pid)

# add a Group instance
#m2.add(patient_group)

# create a Segment named MSA and add it to m2
#msa = m2.add_segment('MSA')

# create a Group named ADT_A01_INSURANCE and add it to m
#g = m.add_group("ADT_A01_INSURANCE")

# assign a Segment instance
#m.pid = pid

# assign a string
#m.pid = "PID|1||566-554-3423^^^GHH^MR||EVERYMAN^ADAM^A|||M|||2222 HOME STREET^^ANN ARBOR^MI^^USA||555-555-2004~444-333-222|||M"
## equivalent to
#m.pid.value = "PID|1||566-554-3423^^^GHH^MR||EVERYMAN^ADAM^A|||M|||2222 HOME STREET^^ANN ARBOR^MI^^USA||555-555-2004~444-333-222|||M"

# copy from another_message child
#m.pid = m2.oml_o33_patient.pid

#print m





#m = core.Message("ADT_A01")
#m.msh.msh_3 = 'GHH_ADT'
#m.msh.msh_7 = '20080115153000'
#m.msh.msh_9 = 'ADT^A01^ADT_A01'
#m.msh.msh_10 = "0123456789"
#m.msh.msh_11 = "P"
#m.msh.msh_16 = "AL"
#m.evn.evn_2 = m.msh.msh_7
#m.evn.evn_4 = "AAA"
#m.evn.evn_5 = m.evn.evn_4

#m.evn.evn_6 = '20080114003000'
#m.pid = "PID|1||566-554-3423^^^GHH^MR||EVERYMAN^ADAM^A|||M|||2222 HOME STREET^^ANN ARBOR^MI^^USA||555-555-2004~444-333-222|||M"
#m.nk1.nk1_1 = '1'
#m.nk1.nk1_2 = 'NUCLEAR^NELDA^W'
#m.nk1.nk1_3 = 'SPO'
#m.nk1.nk1_4 = '2222 HOME STREET^^ANN ARBOR^MI^^USA'

#pprint(m)
#pprint(m.value)

#Message Header Segment
regmsg = core.Message("ADT_A01")
regmsg.msh.msh_9 = 'ADT^A04^ADT_01'
regmsg.msh.msh_10 = ''.join(random.choice('0123456789ABCDEF') for i in range(16))
regmsg.msh.msh_11 = 'P'
regmsg.msh.msh_12 = '2.4'

#Event Segment

regmsg.evn.evn_1 = 'A04'
regmsg.evn.evn_2 = '201301011223'

  
#PID Segment

regmsg.pid = 'PID|||PATID1234^5^M11||JONES^WILLIAM^A^III||19610615|M||2106-3|1200 N ELM STREET^^GREENSBORO^NC^27401-1020|GL|(919)379-1212'

regmsg.pid.pid_3 = 'PATID1234^5^M11' #internal ID
regmsg.pid.pid_5 = 'JONES^WILLIAM^A^III' #patient name
regmsg.pid.pid_7 = 'DOB' #DOB
regmsg.pid.pid_8 = 'M' #Gender
regmsg.pid.pid_13 = '' #Phone (home)
regmsg.pid.pid_16 = ''  #Marital status



#Patient Visit Segment
regmsg.pv1 = 'PV1|1|I|2000^2012^01||||004777^LEBAUER^SIDNEY^J.|||SUR||||1|A0' 


#Insurance info
regmsg.in1 = 'IN1|001|A357|1234|BCMD|||||132987'


pprint(regmsg.value)












